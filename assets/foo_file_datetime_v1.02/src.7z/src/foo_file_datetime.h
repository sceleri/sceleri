#include "../SDK/foobar2000.h"

#define FOO_FILE_DATETIME_FIELD_COUNT 8

class foo_file_datetime : public metadb_display_field_provider
{
private:
	static const char* const m_field_name[FOO_FILE_DATETIME_FIELD_COUNT];
public:
	t_uint32 get_field_count();
	void get_field_name(t_uint32 index, pfc::string_base & out);
	bool process_field(t_uint32 index, metadb_handle * handle, titleformat_text_out * out);
};