#include "foo_file_datetime.h"
#include "../helpers/helpers.h"

//main
const char* const foo_file_datetime::m_field_name[] = { "file_created", "last_accessed", "url_prefix", "is_file", "is_archive", "archive_root", "archive_branch", "archive_type"};


t_uint32 foo_file_datetime::get_field_count()
{
	return FOO_FILE_DATETIME_FIELD_COUNT;
}

void foo_file_datetime::get_field_name(t_uint32 index, pfc::string_base & out)
{
	if (index < FOO_FILE_DATETIME_FIELD_COUNT)
	{
		out = m_field_name[index];
	}
}


bool foo_file_datetime::process_field(t_uint32 index, metadb_handle * handle, titleformat_text_out * out)
{
	const char* url_file_path = handle->get_path();
	if (!url_file_path)
		return false;

	if (index >= 0 && index < 2)
	{	
		pfc::string8 file_path;
		if (archive_impl::g_is_unpack_path(url_file_path))
		{
			pfc::string8 temp;
			pfc::string8 temp2;
			archive_impl::g_parse_unpack_path(url_file_path, temp, temp2);
			if (!foobar2000_io::extract_native_path_ex(temp, file_path))
				file_path = temp;
		}
		else
		{
			if (!foobar2000_io::extract_native_path_ex(url_file_path, file_path))
				file_path = url_file_path;
		}
			

		if (!file_path.is_empty())
		{
			uFindFile * p_find_file = 0;
			p_find_file = uFindFirstFile(file_path);
			if (!p_find_file)
				return false;

			FILETIME file_time;

			switch (index)
			{
			case 0:
				file_time = p_find_file->GetCreationTime();
				break;
			case 1:
				file_time = p_find_file->GetLastAccessTime();
				break;
			default:
				return false;
			}

			SYSTEMTIME system_time_utc, system_time_local;
			FileTimeToSystemTime(&file_time, &system_time_utc);
			SystemTimeToTzSpecificLocalTime(NULL, &system_time_utc, &system_time_local);
			pfc::string_formatter formatted_out;
			formatted_out << pfc::format_int(system_time_local.wYear, 4) << "-" << pfc::format_int(system_time_local.wMonth, 2) << "-" << pfc::format_int(system_time_local.wDay, 2) << " " << pfc::format_int(system_time_local.wHour, 2) << ":" << pfc::format_int(system_time_local.wMinute, 2) << ":" << pfc::format_int(system_time_local.wSecond, 2);
			out->write(titleformat_inputtypes::unknown, formatted_out);
			return true;
		}
		return false;
	}
	else if (index == 2)
	{
		//url_prefix
		const char *pos = strstr(url_file_path, "://");
		if (!pos)
			return false;
		out->write(titleformat_inputtypes::unknown, url_file_path, pos - url_file_path);
		return true;
	}
	else if (index == 3)
	{
		//url_prefix��file://�ł��邩�ǂ���
		if (!foobar2000_io::_extract_native_path_ptr(url_file_path))
			return false;
		out->write_int(titleformat_inputtypes::unknown, 1);
		return true;
	}
	else if (index == 4)
	{
		//archive���̃t�@�C���ł��邩�ǂ���
		if (!archive_impl::g_is_unpack_path(url_file_path))
			return false;
		out->write_int(titleformat_inputtypes::unknown, 1);
		return true;
	}
	else if (index >= 5 && index <= 7)
	{
		//archive�̃p�X�𕪊�
		if (!archive_impl::g_is_unpack_path(url_file_path))
			return false;

		pfc::string8 archive_root;
		pfc::string8 archive_branch;
		pfc::string8 archive_type;
		if (!archive_impl::g_parse_unpack_path_ex(url_file_path, archive_root, archive_branch, archive_type))
			return false;
	
		switch (index)
		{
		case 5:
		{
			const char *archive_root_native = archive_root;
			foobar2000_io::_extract_native_path_ptr(archive_root_native);
			out->write(titleformat_inputtypes::unknown, archive_root_native);
			break;
		}
		case 6:
			out->write(titleformat_inputtypes::unknown, archive_branch);
			break;
		case 7:
			out->write(titleformat_inputtypes::unknown, archive_type);
			break;
		default:
			return false;
		}
		return true;
	}
	return false;
}

static service_factory_single_t<foo_file_datetime> g_foo_file_datetime;

//from SDK: All of global callbacks operate only within main app thread,
class foo_file_datetime_io_callback : public metadb_io_callback
{
	virtual void on_changed_sorted(metadb_handle_list_cref p_items_sorted, bool p_fromhook)
	{
		if (p_fromhook)
			return;

		static_api_ptr_t<metadb_io> mtdb_io;
		mtdb_io->dispatch_refresh(p_items_sorted);	//for %last_accessed%
	}
};
static service_factory_single_t<foo_file_datetime_io_callback> g_foo_file_datetime_io_callback;

// version info
DECLARE_COMPONENT_VERSION("File Date Time",
"1.02",
"You can use the following global variables:\n"
"%file_created%\n"
"%last_accessed%\n"
"%url_prefix%\n"
"%is_file%\n"
"%is_archive%\n"
"%archive_root%\n"
"%archive_branch%\n"
"%archive_type%"
)

// This will prevent users from renaming your component around (important for proper troubleshooter behaviors) or loading multiple instances of it.
VALIDATE_COMPONENT_FILENAME("foo_file_datetime.dll");